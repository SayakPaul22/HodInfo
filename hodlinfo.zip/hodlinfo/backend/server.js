const express = require('express');
const mongoose = require('mongoose');
const axios = require('axios');

const app = express();
const port = 3000;

app.use(express.static('public')); // Serve static files from the 'public' directory

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/hodlinfo', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const tickerSchema = new mongoose.Schema({
  name: String,
  last: Number,
  buy: Number,
  sell: Number,
  volume: Number,
  base_unit: String,
});

const Ticker = mongoose.model('Ticker', tickerSchema);

// Fetch and store data from WazirX API
async function fetchAndStoreData() {
  try {
    const response = await axios.get('https://api.wazirx.com/api/v2/tickers');
    const tickers = Object.values(response.data).slice(0, 10);
    await Ticker.deleteMany({}); // Clear previous data
    for (const ticker of tickers) {
      const newTicker = new Ticker({
        name: ticker.symbol,
        last: ticker.last,
        buy: ticker.buy,
        sell: ticker.sell,
        volume: ticker.volume,
        base_unit: ticker.base_unit,
      });
      await newTicker.save();
    }
    console.log('Data fetched and stored successfully');
  } catch (error) {
    console.error('Error fetching data:', error);
  }
}

// Fetch data and store it every hour
fetchAndStoreData();
setInterval(fetchAndStoreData, 3600000); // 1 hour in milliseconds

// Serve API endpoint
app.get('/api/tickers', async (req, res) => {
  try {
    const tickers = await Ticker.find();
    res.json(tickers);
  } catch (error) {
    res.status(500).send(error);
  }
});

// Start server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
